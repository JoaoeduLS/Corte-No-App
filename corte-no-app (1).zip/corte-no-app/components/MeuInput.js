import React from "react";
import { TextInput, StyleSheet, View } from "react-native";
import MaskInput from 'react-native-mask-input';

const MeuInput = ({
  value,
  keyboardType,
  placeholder,
  onChangeText,
  secureTextEntry,
  maxLength,
  mask
}) => {
  return (

    <MaskInput
      value={value}
      keyboardType={keyboardType}
      style={styles.input}
      placeholder={placeholder}
      placeholderTextColor="#DCDCDC"
      autoCorrect={false}
      onChangeText={onChangeText}
      secureTextEntry={secureTextEntry}
      maxLength={maxLength}
      mask={mask}
    />

  );
};

const styles = StyleSheet.create({
  input: {
    padding: 10,
    color: 'white',
    width: 240
  },

});

export default MeuInput;