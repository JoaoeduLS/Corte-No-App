import React, { useState, useEffect } from 'react';
import { NavigationContainer } from '@react-navigation/native';

import Splash from './screens/Splash';
import MainNavigator from './routes/MainNavigator';
import * as firebase from 'firebase';
import { UserProvider } from './contexts/UserContexts';

const firebaseConfig = {
  apiKey: "AIzaSyAFezGp3oKU107akXTqoW-DZpkEZgJZK6Q",
  authDomain: "corte-no-app.firebaseapp.com",
  projectId: "corte-no-app",
  storageBucket: "corte-no-app.appspot.com",
  messagingSenderId: "424837874604",
  appId: "1:424837874604:web:9da05fd731bbb4cfbb7009",
  measurementId: "G-3P721GPDRR"
};
if(!firebase.apps.length){
   firebase.initializeApp(firebaseConfig)
}


export default function App() {

  const [exibeSplash, setexibeSplash] = useState(true);
  
  useEffect(() => {
      setTimeout(() => setexibeSplash(false), 3000);
    }, []);

  return (
    <UserProvider>
      {exibeSplash ? <Splash/> : <MainNavigator/>}
    </UserProvider>
  )
}