import React, { createContext, useState } from 'react';

const UserContext = createContext();

const UserProvider = (props) => {
  const [logado, setLogado] = useState(false);
  return (
    <UserContext.Provider value={[logado, setLogado]}>
      {props.children}
    </UserContext.Provider>
  );
};
export { UserContext, UserProvider };
