import React, { useState } from "react";
import {
  View,
  TextInput,
  Text,
  TouchableOpacity,
  StyleSheet,
  ImageBackground,
  TouchableWithoutFeedback,
  ScrollView,
  KeyboardAvoidingView,
} from "react-native";
import { useForm, Controller } from "react-hook-form";
import Icon from 'react-native-vector-icons/Ionicons';
import MeuInput from "../components/MeuInput";
import { StatusBar } from 'expo-status-bar';
import * as firebase from 'firebase';


const EsqueciSenha = ({navigation}) => {

  const [email, setEmail] = useState('');

  async function redefinirSenha(){
        await firebase
        .auth()
        .sendPasswordResetEmail(email)
        .then(() => {
            alert('Verifique sua caixa de e-mail.')
            navigation.navigate('Login')
        })
        .catch((error) => {
            var errorCode = error.code;
            var errorMessage = error.message;
            console.log(errorCode);
            console.log(errorMessage);
        });
    }

  

  return (

    <ImageBackground source={require('../assets/fundo.jpg')} resizeMode="cover" style={styles.container}>

      <KeyboardAvoidingView>

        <ScrollView>

          <Text style={styles.textoInformacao}>informe e-mail cadastrado</Text>

          <View style={styles.inputContainer}>

            <TouchableWithoutFeedback>
              <Icon style={styles.icon} name="at-outline" size={20} color="white"/>
            </TouchableWithoutFeedback>

            <MeuInput
              placeholder='EMAIL'
              value={email}
              onChangeText={(text) => setEmail(text)}
            />

          </View>

          <TouchableOpacity
            style={styles.botao1}
            onPress={redefinirSenha}
          >
            <Text style={styles.botaotexto1}>CONTINUAR</Text>
          </TouchableOpacity>

        </ScrollView>

      </KeyboardAvoidingView>

      <StatusBar style='light'/>

    </ImageBackground>

  );
};

const styles = StyleSheet.create({
  container: {
    flex: 1,
    padding: 16,
    justifyContent: 'center',
  },
  inputContainer: {
    borderColor: '#FF5C00',
    borderWidth: 1,
    paddingLeft: 10,
    marginTop: 15,
    borderRadius: 45,
    flexDirection: 'row',
  },
  icon: {
    alignSelf: 'center',
  },
  botao1: {
    alignSelf: 'center',
    alignItems: 'center',
    justifyContent: 'center',
    width: 250,
    height: 30,
    backgroundColor: '#FF5C00',
    borderRadius: 45,
    marginTop: 30,
  },
  botaotexto1: {
    fontSize: 18,
    fontWeight: 'bold',
  },
  textoInformacao: {
    fontSize: 20,
    color: 'white',
    textAlign: 'center',
    fontVariant: ['small-caps'],
    fontWeight: 'normal',
    marginBottom: 20,
  }
});

export default EsqueciSenha;