import React, { useEffect, Component } from 'react';
import { View, Text, StyleSheet, SafeAreaView, ScrollView, Image, ImageBackground, TouchableOpacity, Alert, Picker } from 'react-native';
import { useNavigation } from '@react-navigation/native';
import CalendarPicker from 'react-native-calendar-picker';
import { StatusBar } from 'expo-status-bar';
import * as firebase from 'firebase'

export default class Agendamento extends Component {

  constructor(props) {
    super(props);
    this.state = {
      selectedStartDate: null,
    };
    this.onDateChange = this.onDateChange.bind(this);
  }

  onDateChange(date) {
    this.setState({
      selectedStartDate: date,
    });
  }

  render() {

    const minDate = new Date();
    const { selectedStartDate } = this.state;
    const startDate = selectedStartDate ? selectedStartDate.toString() : '';
    
    const { navigation, route } = this.props

    const email = route.params.email;

    const id = route.params.id;
    const nome = route.params.nome;
    const servicos = route.params.servicos;
    const precos = route.params.precos;
    const imagem = route.params.imagem;

    function alertaAgendamento()  {
      navigation.push('Home', {'email':email})
      {/*
      Alert.alert(
        "Agendameto concluído",
        "Seu agendamento foi efetuado com êxito!\n\nObs.: O pagamento será feito na própria barbearia, com as políticas do próprio comércio.",
        [
          {
            text: "Voltar ás barbearias",
            onPress: () => {navigation.push('Home')}
          },
        ]
      );
      */}
    }
  

  return(
      <ImageBackground source={require('../assets/fundo.jpg')} resizeMode="cover" style={styles.container}>
        <ScrollView>
            <View style={styles.modalItem}>
                
                    <View style={styles.userInfo}>
                        <Image source={imagem} style={styles.userAvatar} />
                        <Text style={styles.userName}>{nome}</Text>
                    </View>
                
            </View>
            <View style={styles.modalItem}>
                <View style={styles.serviceInfo}>
                    <Text style={styles.serviceName}>{servicos}</Text>
                    <Text style={styles.servicePrice}>R$ {precos}</Text>
                </View>
            </View>
            <View style={styles.modalItem}>

                <CalendarPicker
                  onDateChange={this.onDateChange}
                  selectedDayColor={'#FF5C00'}
                  minDate={minDate}
                  weekdays={['Dom', 'Seg', 'Ter', 'Qua', 'Qui', 'Sex', 'Sab']}
                  months={['Janeiro', 'Fevereiro', 'Março', 'Abril', 'Maio', 'Junho', 'Julho', 'Agosto', 'Setembro', 'Outubro', 'Novembro', 'Dezembro']}
                  previousTitle="Anterior"
                  nextTitle="Próximo"
                  textStyle={{
                    fontVariant: ['small-caps'],
                    fontWeight: 'normal',
                  }}
                />

                <View>
                  <Text style={styles.textoData}>Data selecionada: { startDate.replace(' 12:00:00 GMT-0300', '') }</Text>
                </View>
                
            </View>
            <View style={styles.modalItem}>
                
                    <ScrollView style={styles.viewScroll} horizontal={true} showsHorizontalScrollIndicator={false}>
                            
                            <TouchableOpacity style={styles.timeItem} source={require('../assets/nav_prev.png')}>
                                    <Text style={styles.timeItemText}>10:30</Text>

                            </TouchableOpacity>
                            <TouchableOpacity style={styles.timeItem} source={require('../assets/nav_prev.png')}>
                                    <Text style={styles.timeItemText}>11:00</Text>

                            </TouchableOpacity>
                            <TouchableOpacity style={styles.timeItem} source={require('../assets/nav_prev.png')}>
                                    <Text style={styles.timeItemText}>12:00</Text>

                            </TouchableOpacity>
                            <TouchableOpacity style={styles.timeItem} source={require('../assets/nav_prev.png')}>
                                    <Text style={styles.timeItemText}>14:00</Text>

                            </TouchableOpacity>
                            <TouchableOpacity style={styles.timeItem} source={require('../assets/nav_prev.png')}>
                                    <Text style={styles.timeItemText}>15:00</Text>

                            </TouchableOpacity>
                            <TouchableOpacity style={styles.timeItem} source={require('../assets/nav_prev.png')}>
                                    <Text style={styles.timeItemText}>16:00</Text>

                            </TouchableOpacity>
                            
                    </ScrollView>
                

            </View>

            <TouchableOpacity
              style={styles.botao}
              onPress={() => {
                startDate == '' ?
                  alert('Selecione uma data!')
                :
                  firebase
                    .firestore()
                    .collection('Agendamentos')
                    .add({ Data: startDate.replace(' 12:00:00 GMT-0300', ''), Barbearia: nome, Servico: servicos, Precos: precos, EmailCliente: email })
                    .then((docRef) => {})
                  alert('Agendamento concluído com sucesso!')
                  navigation.navigate('Home', {'email':email})
              }}
            >
              <Text style={styles.botaotexto}>AGENDAR</Text>
            </TouchableOpacity>
               
        </ScrollView>

        <StatusBar style='light'/>
        
      </ImageBackground>
  )
}}

const styles = StyleSheet.create({
  container: {
		flex:1,
		justifyContent:"center",
    paddingVertical: 16,
    paddingHorizontal: 8,
	},
  modalItem: {
    backgroundColor: "#DCDCDC",
    borderRadius: 10,
    marginBottom: 16,
    padding: 10,
  },
  userInfo: {
    flexDirection: "row",
    alignItems: "center"
  },
  userAvatar:{
    width: 100,
    height: 100,
    borderRadius: 20,
    marginRight: 15,
  },
  userName: {
    color: "#000000",
    fontSize:20,
    fontVariant: ['small-caps'],
    fontWeight: 'bold',
  },
  serviceInfo: {
    flexDirection: "row",
    justifyContent: "space-between"
  },
  serviceName: {
    fontSize: 18,
    fontWeight: "bold",
    fontVariant: ['small-caps'],
  },
  servicePrice: {
    fontSize: 18,
    fontWeight: "bold"
  },
  timeItem: {
    width: 75,
    height: 40,
    justifyContent: "center",
    alignItems: "center",
    borderRadius: 10,
  },
  timeItemText: {
    fontSize: 16
  },
  viewScroll: {
    flexDirection: "row",
    alignItems: "center",

  },
  botao: {
    alignSelf: 'center',
    alignItems: 'center',
    justifyContent: 'center',
    width: 250,
    height: 30,
    backgroundColor: '#FF5C00',
    borderRadius: 45,
  },
  botaotexto: {
    fontSize: 18,
    fontWeight: 'bold',
  },
  textoData: {
    fontVariant: ['small-caps'],
    fontWeight: 'normal',
  },
})