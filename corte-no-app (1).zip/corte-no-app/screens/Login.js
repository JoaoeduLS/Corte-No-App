import React, { useState, useEffect, useContext } from "react";
import {
  View,
  KeyboardAvoidingView,
  Image,
  TextInput,
  Text,
  TouchableOpacity,
  StyleSheet,
  ImageBackground,
  TouchableWithoutFeedback,
  Alert,
  ScrollView,
  Animated,
  Keyboard,
} from "react-native";
import { StatusBar } from 'expo-status-bar';
import { useForm, Controller } from "react-hook-form";
import Icon from 'react-native-vector-icons/Ionicons';
import MeuInput from "../components/MeuInput";
import * as firebase from 'firebase';


const Login = ({ navigation }) => {

  const [logo] = useState(new Animated.ValueXY({x: 200, y: 284}));

  useEffect(() => {
    const keyboardDidShowListener = Keyboard.addListener('keyboardDidShow', keyboardDidShow);
    const keyboardDidHideListener = Keyboard.addListener('keyboardDidHide', keyboardDidHide);
  })

  function keyboardDidShow(){
    Animated.parallel([
      Animated.timing(logo.x, {
        toValue: 80,
        duration: 100,
        useNativeDriver: false
      }),
      Animated.timing(logo.y, {
        toValue: 113,
        duration: 100,
        useNativeDriver: false
      })
    ]).start();
  }

  function keyboardDidHide(){
    Animated.parallel([
      Animated.timing(logo.x, {
        toValue: 200,
        duration: 100,
        useNativeDriver: false,
      }),
      Animated.timing(logo.y, {
        toValue: 284,
        duration: 100,
        useNativeDriver: false,
      })
    ]).start();
  }

  const [hidePass, setHidePass] = useState(true);
  const [email, setEmail] = useState('');
  const [senha, setSenha] = useState('');


  return (

    <ImageBackground source={require('../assets/fundo.jpg')} resizeMode="cover" style={styles.container}>

      <KeyboardAvoidingView>

        <ScrollView style={{justifyContent: "center"}}>

          <Animated.Image
            style={{
              width: logo.x,
              height: logo.y,
              alignSelf: 'center',
              marginTop: 30
              }}
            source={require("../assets/Logo.png")}
          />

          <View style={styles.inputContainer}>

            <TouchableWithoutFeedback>
              <Icon style={styles.icon} name="at-outline" size={20} color="white"/>
            </TouchableWithoutFeedback>

            <MeuInput
              placeholder='EMAIL'
              value={email}
              onChangeText={(text) => setEmail(text)}
            />

          </View>

          <View style={styles.inputContainer}>

            <TouchableWithoutFeedback>
              <Icon style={styles.icon} name="lock-closed-outline" size={20} color="white"/>
            </TouchableWithoutFeedback>

            <MeuInput
              placeholder="SENHA"
              value={senha}
              onChangeText={(text) => setSenha(text)}
              secureTextEntry={hidePass}
            />

            <TouchableWithoutFeedback onPress={() => setHidePass(!hidePass)}>
              { hidePass ?
                <Icon style={styles.iconHide} name="eye-outline" size={20} color="white"/>
                :
                <Icon style={styles.iconHide} name="eye-off-outline" size={20} color="white"/>
              }
            </TouchableWithoutFeedback>

          </View>


          <TouchableOpacity
            style={styles.botao1}
            onPress={() => {
              firebase
              .auth()
              .signInWithEmailAndPassword(email, senha)
              .then((userCredential) => navigation.navigate('Home', {'email':email}))
              .catch((error) => alert(error.message));
            }}
          >
            <Text style={styles.botaotexto1}>ENTRAR</Text>
          </TouchableOpacity>

          <TouchableOpacity
            style={styles.botao2}
            onPress={() => {navigation.push('EsqueciASenha')}}
          >
            <Text style={styles.botaotexto2}>ESQUECI A SENHA</Text>
          </TouchableOpacity>

          <View style={{flexDirection: 'row', marginTop: 40, marginHorizontal: 40}}>
            <Text style={styles.textoncadastro}>não tem cadastro?</Text>
            <TouchableOpacity onPress={() => {navigation.push('Cadastro')}}>
              <Text style={styles.textoInscrevase}>inscreva-se</Text>
            </TouchableOpacity>
          </View>

        </ScrollView>

      </KeyboardAvoidingView>

      <StatusBar style='light'/>

    </ImageBackground>

  );
};

const styles = StyleSheet.create({
  container: {
    flex: 1,
    padding: 16,
    alignItems: 'center'
  },
  inputContainer: {
    borderColor: '#FF5C00',
    borderWidth: 1,
    paddingLeft: 10,
    marginTop: 15,
    borderRadius: 45,
    flexDirection: 'row',
  },
  icon: {
    alignSelf: 'center',
  },
  iconHide: {
    alignSelf: 'center',
    marginRight: 25,
  },
  textoncadastro: {
    color: 'white',
    fontVariant: ['small-caps'],
    fontWeight: 'normal',
    fontSize: 16,
    flex: 1,
  },
  textoInscrevase: {
    color: '#FF5C00',
    fontVariant: ['small-caps'],
    fontWeight: 'normal',
    fontSize: 18,
    flex:1
  },
  botao1: {
    alignSelf: 'center',
    alignItems: 'center',
    justifyContent: 'center',
    width: 250,
    height: 30,
    backgroundColor: '#FF5C00',
    borderRadius: 45,
    marginTop: 30,
  },
  botao2: {
    alignSelf: 'center',
    borderWidth: 1,
    borderColor: '#FF5C00',
    alignItems: 'center',
    justifyContent: 'center',
    width: 150,
    height: 20,
    marginTop: 20,
    borderRadius: 45,
  },
  botaotexto1: {
    fontSize: 18,
    fontWeight: 'bold',
  },
  botaotexto2: {
    color: 'white',
    fontSize: 12,
  },
});

export default Login;