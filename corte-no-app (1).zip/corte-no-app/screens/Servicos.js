import React, { useState } from "react";
import {
  View,
  Text,
  StyleSheet,
  ImageBackground,
  FlatList,
  TouchableOpacity,
  ScrollView,
  Image,
  Animated,
} from "react-native";
import * as firebase from 'firebase';
import { StatusBar } from 'expo-status-bar';

const Servicos = ({navigation, route}) => {

  const email = route.params.email;

  const id = route.params.id;
  const nome = route.params.nome;
  const servicos = route.params.servicos;
  const precos = route.params.precos;
  const telefone = route.params.telefone;
  const imagem = route.params.imagem;

  const [scrollY, setScrollY] = useState(new Animated.Value(0));

  return (

    <ImageBackground source={require('../assets/fundo.jpg')} resizeMode="cover" style={styles.container}>

      <Animated.View style={{
          flexDirection: 'row',
          padding: 16,
          alignItems: 'center',
          backgroundColor: '#00000099',
          height: scrollY.interpolate({
            inputRange:[1, 160, 185],
            outputRange: [176, 100, 80],
            extrapolate: 'clamp'
          }),
        }}
      >
        <Animated.Image
          style={{
            height: scrollY.interpolate({
             inputRange:[1, 75, 170],
             outputRange: [120, 60, 0] 
            }),
            width: scrollY.interpolate({
              inputRange:[1, 75, 170],
              outputRange: [120, 60, 0] 
            }),
            opacity: scrollY.interpolate({
              inputRange:[1, 75, 170],
              outputRange: [1, 0, 0],
              extrapolate: 'clamp'
            }),
            borderRadius: 20,
            resizeMode: 'cover',
          }}
          source={imagem}
          resizeMode='center'
        />
        <View style={{flex: 1, alignItems: 'center', justifyContent: 'center', flexDirection: 'column'}}>
          <Text style={{
              fontSize: 24,
              color: '#FF5C00',
              fontVariant: ['small-caps'],
              fontWeight: 'normal',
            }}
          >
            {nome}
          </Text>
          <Animated.Text style={{
              fontSize: scrollY.interpolate({
                inputRange:[1, 75, 170],
                outputRange: [16, 8, 0],
                extrapolate: 'clamp'
              }),
              color: '#DCDCDC',
              opacity: scrollY.interpolate({
                inputRange:[1, 75, 170],
                outputRange: [1, 0, 0],
                extrapolate: 'clamp'
              }),
           }}
          >
            {telefone}
          </Animated.Text>
        </View>
      </Animated.View>
      
      <ScrollView
        scrollEventThrottle={16}
        onScroll={Animated.event([{
            nativeEvent: {
              contentOffset: { y: scrollY }
            },
          }],
          { useNativeDriver: false })}
        >

        <FlatList 
          data={servicos}
          keyExtractor={item=>item.id}
          renderItem={({item, index}) =>
            
            <View style={styles.card}>
              <View style={{flexDirection: 'row'}}>
                <View style={{flexDirection: 'column', flex: 2}}>
                  <Text style={styles.servico}>{item}</Text>
                  <Text style={styles.preco}>R$ {precos[index].padEnd(8)}{/*item.preco.toFixed(2).padEnd(8)*/}</Text>
                </View>
                <TouchableOpacity
                  style={styles.botao1}
                  onPress={() => navigation.navigate('Agendamento', {"id": id, "nome": nome, "servicos": servicos[index], "precos": precos[index], "imagem": imagem, 'email':email})}
                >
                  <Text style={styles.botaotexto1}>AGENDAR</Text>
                </TouchableOpacity>
              </View>
            </View>
            
          }
        />

      </ScrollView>

      <StatusBar style='light'/>

    </ImageBackground>

  );
};

const styles = StyleSheet.create({
  container: {
    flex: 1,
  },
  servico: {
    fontSize: 18,
    color: 'black',
    fontVariant: ['small-caps'],
    fontWeight: 'bold',
  },
  preco: {
    fontSize: 14,
    color: 'black',
    fontVariant: ['small-caps'],
    fontWeight: 'bold',
  },
  card: {
    backgroundColor: '#DCDCDC',
    marginTop: 14,
    margin: 16,
    paddingHorizontal: 10,
    paddingBottom: 10,
    paddingTop: 8,
    borderRadius: 20,
  },
  botao1: {
    alignSelf: 'center',
    alignItems: 'center',
    justifyContent: 'center',
    width: 250,
    height: 30,
    backgroundColor: '#FF5C00',
    borderRadius: 45,
    flex: 1,
    elevation: 10,
  },
  botaotexto1: {
    fontSize: 14,
    fontWeight: 'bold',
  },
});

export default Servicos;