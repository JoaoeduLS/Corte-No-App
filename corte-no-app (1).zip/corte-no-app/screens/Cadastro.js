import React, { useState, useEffect } from "react";
import {
  View,
  Image,
  TextInput,
  Text,
  TouchableOpacity,
  StyleSheet,
  ImageBackground,
  TouchableWithoutFeedback,
  ScrollView,
  Alert,
  Picker,
  KeyboardAvoidingView,
  Animated,
  Keyboard,
} from "react-native";
import { StatusBar } from 'expo-status-bar';
import { Ionicons, MaterialCommunityIcons } from '@expo/vector-icons';
import * as firebase from 'firebase';
import MeuInput from "../components/MeuInput";


const Cadastro = ({navigation}) => {

  const [logo] = useState(new Animated.ValueXY({x: 150, y: 213}));

  useEffect(() => {
    const keyboardDidShowListener = Keyboard.addListener('keyboardDidShow', keyboardDidShow);
    const keyboardDidHideListener = Keyboard.addListener('keyboardDidHide', keyboardDidHide)
  })

  function keyboardDidShow(){
    Animated.parallel([
      Animated.timing(logo.x, {
        toValue: 80,
        duration: 100,
        useNativeDriver: false
      }),
      Animated.timing(logo.y, {
        toValue: 113,
        duration: 100,
        useNativeDriver: false
      })
    ]).start();
  }

  function keyboardDidHide(){
    Animated.parallel([
      Animated.timing(logo.x, {
        toValue: 150,
        duration: 100,
        useNativeDriver: false,
      }),
      Animated.timing(logo.y, {
        toValue: 213,
        duration: 100,
        useNativeDriver: false,
      })
    ]).start();
  }  

  const [selectedValue, setSelectedValue] = useState("pergunta1");

  const [hidePass, setHidePass] = useState(true);
  const [hidePass1, setHidePass1] = useState(true);


  function alertaCadastro() {
    Alert.alert(
      "Cadastrado",
      "Usuário cadastrado com sucesso! Volte para efetuar o login.",
      [
        {
          text: "Voltar ao login",
          onPress: () => {navigation.push('Login')},
        },
      ]
    );
  }

  const [nome, setNome] = useState('');
  const [email, setEmail] = useState('');
  const [telefone, setTelefone] = useState('');
  const [novaSenha, setNovaSenha] = useState('');
  const [confirmarSenha, setConfirmarSenha] = useState('');

  return (

    <ImageBackground source={require('../assets/fundo.jpg')} resizeMode="cover" style={styles.container}>

      <KeyboardAvoidingView>

        <ScrollView>

          <View style={{paddingTop: 30}}>
            <Animated.Image
              style={{
                width: logo.x,
                height: logo.y,
                alignSelf: 'center',
                }}
              source={require("../assets/Logo.png")}
            />
          </View>


          <View style={styles.inputContainer}>

            <TouchableWithoutFeedback>
              <Ionicons style={styles.icon} name="person-outline" size={20} color="white"/>
            </TouchableWithoutFeedback>

            <MeuInput
              placeholder='NOME COMPLETO'
              value={nome}
              onChangeText={(text) => setNome(text)}
            />

          </View>


          <View style={styles.inputContainer}>

            <TouchableWithoutFeedback>
                <Ionicons style={styles.icon} name="at-outline" size={20} color="white"/>
            </TouchableWithoutFeedback>

            <MeuInput
              placeholder='EMAIL'
              value={email}
              onChangeText={(text) => setEmail(text)}
              keyboardType='email-address'
            />

          </View>


          <View style={styles.inputContainer}>

            <TouchableWithoutFeedback>
                <Ionicons style={styles.icon} name="call-outline" size={20} color="white"/>
            </TouchableWithoutFeedback>

            <MeuInput
              placeholder='TELEFONE'
              value={telefone}
              onChangeText={(text) => setTelefone(text)}
              keyboardType='phone-pad'
              maxLength={15}
              mask={['(', /\d/, /\d/, ')', ' ', /\d/, /\d/, /\d/, /\d/, /\d/, '-', /\d/, /\d/, /\d/, /\d/]}
            />

          </View>


          <View style={styles.inputContainer}>

            <TouchableWithoutFeedback>
              <Ionicons style={styles.icon} name="lock-closed-outline" size={20} color="white"/>
            </TouchableWithoutFeedback>

            <MeuInput
              placeholder="SENHA"
              value={novaSenha}
              onChangeText={(text) => setNovaSenha(text)}
              secureTextEntry={hidePass}
            />

            <TouchableWithoutFeedback onPress={() => setHidePass(!hidePass)}>
              { hidePass ?
                <Ionicons style={styles.iconHide} name="eye-outline" size={20} color="white"/>
                :
                <Ionicons style={styles.iconHide} name="eye-off-outline" size={20} color="white"/>
              }
            </TouchableWithoutFeedback>

          </View>


          <View style={styles.inputContainer}>

            <TouchableWithoutFeedback>
              <Ionicons style={styles.icon} name="lock-closed-outline" size={20} color="white"/>
            </TouchableWithoutFeedback>

            <MeuInput
              placeholder="CONFIRMAR SENHA"
              value={confirmarSenha}
              onChangeText={(text) => setConfirmarSenha(text)}
              secureTextEntry={hidePass1}
            />

            <TouchableWithoutFeedback onPress={() => setHidePass1(!hidePass1)}>
              { hidePass1 ?
                <Ionicons style={styles.iconHide} name="eye-outline" size={20} color="white"/>
                :
                <Ionicons style={styles.iconHide} name="eye-off-outline" size={20} color="white"/>
              }
            </TouchableWithoutFeedback>

          </View>


          <TouchableOpacity
            style={styles.botao1}
            onPress={() => {
              firebase
                .auth()
                .createUserWithEmailAndPassword(email, confirmarSenha)
                .then((userCredential) => {navigation.push('Login')})
                .catch((error) => alert(error.message)),
              firebase
                .firestore()
                .collection('Clientes')
                .add({ Email: email, Nome: nome, Telefone: telefone })
                .then((docRef) => {})
            }}
          >
            <Text style={styles.botaotexto1}>CADASTRAR</Text>
          </TouchableOpacity>

        </ScrollView>

      </KeyboardAvoidingView>

      <StatusBar style='light'/>

    </ImageBackground>

  );
};

const styles = StyleSheet.create({
  container: {
    flex: 1,
    padding: 16,
  },
  inputContainer: {
    borderColor: '#FF5C00',
    borderWidth: 1,
    paddingLeft: 10,
    marginTop: 15,
    borderRadius: 45,
    flexDirection: 'row',
  },
  icon: {
    alignSelf: 'center',
  },
  iconHide: {
    alignSelf: 'center',
    marginLeft: 10,
  },
  botao1: {
    alignSelf: 'center',
    alignItems: 'center',
    justifyContent: 'center',
    width: 250,
    height: 30,
    backgroundColor: '#FF5C00',
    borderRadius: 45,
    marginTop: 30,
  },
  botaotexto1: {
    fontSize: 18,
    fontWeight: 'bold',
  },
});

export default Cadastro;