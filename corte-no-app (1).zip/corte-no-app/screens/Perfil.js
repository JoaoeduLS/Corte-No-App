import React, { useState, useContext, useEffect } from "react";
import {
  KeyboardAvoidingView,
  StyleSheet,
  ImageBackground,
  ScrollView,
  Image,
  Text,
  View,
  FlatList,
  TouchableOpacity,
  Alert,
} from "react-native";
import Icon from 'react-native-vector-icons/Ionicons';
import { StatusBar } from 'expo-status-bar';
import { Ionicons } from '@expo/vector-icons';
import * as firebase from 'firebase';


const Peril = ({navigation, route}) => {

  const email = route.params.email;

  const [user, setUser] = useState([]);

  useEffect(() => {
    const unsubscribe = navigation.addListener('focus', () => {
      firebase
        .firestore()
        .collection('Clientes')
        .where('Email', '==', email)
        .get()
        .then((querySnapshot) => {
          const dados = [];
          querySnapshot.forEach((doc) => {
            dados.push({ id: doc.id, ...doc.data() });
          });
          setUser(dados);
        })
        .catch((error) => alert(error.message));
    });

    return unsubscribe;
  }, [navigation, email]);


  function alertaSair() {
    navigation.navigate('Login')
    {/*
    Alert.alert(
      "Sair",
      "Tem certeza que deseja sair?",
      [
        {
          text: "Cancelar",
        },
        {
          text: "Sair",
          onPress: () => {setLogado(false);},
        },
      ]
    );
    */}
  }

  function alertaDeletarConta() {
    {/*
    Alert.alert(
      "Deletar conta",
      "Tem certeza que deseja deletar sua conta? Esta ação não pode ser desfeita.",
      [
        {
          text: "Cancelar",
        },
        {
          text: "Deletar",
          onPress: () =>
              navigation.navigate('Login')
        },
      ]
    );
    */}
  }

  return (

    <ImageBackground source={require('../assets/fundo.jpg')} resizeMode="cover" style={styles.container}>

      <KeyboardAvoidingView>

        <ScrollView>

          <Image
            style={styles.logo}
            source={require("../assets/avatar.jpg")}
          /> 
          
          {/*<View style={{marginBottom: 30, marginLeft: 16}}>
            <Text style={styles.informacao}>Nome</Text>
            <Text style={styles.dado}>{user.Nome}</Text>
          </View>
          <View style={{marginBottom: 30, marginLeft: 16}}>
            <Text style={styles.informacao}>Email</Text>
            <Text style={styles.dado}>{user.Email}</Text>
          </View>
          <View style={{marginBottom: 30, marginLeft: 16}}>
            <Text style={styles.informacao}>Telefone</Text>
            <Text style={styles.dado}>{user.Telefone}</Text>
          </View>*/}
          
          <FlatList 
            data={user}
            renderItem={({item}) =>
              <View>
                <View style={{marginBottom: 30, marginLeft: 16}}>
                  <View style={{flexDirection: 'row'}}>
                    <Ionicons style={styles.icon} name="person-outline" size={16} color="#DCDCDC"/>
                    <Text style={styles.informacao}>Nome</Text>
                  </View>
                  <Text style={styles.dado}>{item.Nome}</Text>
                </View>
                <View style={{marginBottom: 30, marginLeft: 16}}>
                  <View style={{flexDirection: 'row'}}>
                    <Ionicons style={styles.icon} name="at-outline" size={16} color="#DCDCDC"/>
                    <Text style={styles.informacao}>Email</Text>
                  </View>
                  <Text style={styles.dado}>{item.Email}</Text>
                </View>
                <View style={{marginBottom: 30, marginLeft: 16}}>
                  <View style={{flexDirection: 'row'}}>
                    <Ionicons style={styles.icon} name="call-outline" size={16} color="#DCDCDC"/>
                    <Text style={styles.informacao}>Telefone</Text>
                  </View>
                  <Text style={styles.dado}>{item.Telefone}</Text>
                </View>
                <TouchableOpacity
                  style={styles.botao}
                  onPress={alertaSair}
                >
                  <Text style={styles.botaotexto}>SAIR</Text>
                </TouchableOpacity>

                <TouchableOpacity
                  style={styles.botao2}
                  onPress={() => {
                    firebase
                      .auth()
                      .currentUser
                      .delete()
                      .then(() => navigation.navigate('Login')),
                    firebase
                      .firestore()
                      .collection('Clientes')
                      .doc(item.id)
                      .delete()
                      .then((docRef) => {})
                  }}
                >
                  <Text style={styles.botaotexto2}>DELETAR CONTA</Text>
                </TouchableOpacity>
              </View>
            }
          />

        </ScrollView>

      </KeyboardAvoidingView>

      <StatusBar style='light'/>

    </ImageBackground>

  );
};

const styles = StyleSheet.create({
  container: {
    flex: 1,
    padding: 16,
    justifyContent: 'center',
  },
  logo: {
    width: 200,
    height: 200,
    alignSelf: 'center',
    marginBottom: 40,
    borderRadius: 100,
  },
  informacao: {
    color: '#DCDCDC',
    fontVariant: ['small-caps'],
    fontWeight: 'normal',
    marginBottom: 3,
  },
  dado: {
    color: 'white',
    fontVariant: ['small-caps'],
    fontWeight: 'normal',
    fontSize: 22,
  },
  icon: {
    marginRight: 3,
  },
  botao: {
    alignSelf: 'center',
    alignItems: 'center',
    justifyContent: 'center',
    width: 250,
    height: 30,
    backgroundColor: 'red',
    borderRadius: 45,
    marginTop: 30,
  },
  botaotexto: {
    color: 'white',
    fontSize: 18,
    fontWeight: 'bold',
  },
  botao2: {
    alignSelf: 'center',
    borderWidth: 1,
    borderColor: 'red',
    alignItems: 'center',
    justifyContent: 'center',
    width: 150,
    height: 20,
    marginTop: 20,
    borderRadius: 45,
  },
  botaotexto2: {
    color: 'red',
    fontSize: 12,
  },
});

export default Peril;