import React, { useEffect, useState } from "react";
import { 
  View, 
  FlatList, 
  Text, 
  StyleSheet, 
  Image, 
  TouchableOpacity,
  ImageBackground,
  Alert,
  TouchableWithoutFeedback,
  TextInput
} from "react-native";
import { Ionicons } from '@expo/vector-icons';
import { MaterialCommunityIcons } from '@expo/vector-icons';
import * as firebase from 'firebase';
import { StatusBar } from 'expo-status-bar';

const Home = ({ navigation, route }) => {

  const email = route.params.email;

  const [barbearias, setBarbearias] = useState([]);
  const [originalData, setOriginalData] = useState([]);

  useEffect(() => {
    const unsubscribe = navigation.addListener('focus', () => {
      firebase
        .firestore()
        .collection('Barbearias')
        .get()
        .then((querySnapshot) => {
          const dados = [];
          querySnapshot.forEach((doc) => {
            dados.push({ id: doc.id, ...doc.data() });
          });
          setBarbearias(dados), setOriginalData(dados);
        })
        .catch((error) => alert(error.message));
    });

    return unsubscribe;
  }, [navigation]);

  function alertaFab() {
    navigation.navigate('Perfil', {'email':email})
    {/*
    Alert.alert(
      "Perfil",
      "Deseja ver seu perfil?",
      [
        {
          text: "Cancelar",
        },
        {
          text: "Ver perfil",
          onPress: () => {navigation.push('Perfil')},
        },
      ]
    );
    */}
  }

  function search(s){
    let arr = JSON.parse(JSON.stringify(originalData));
    setBarbearias(arr.filter(b => 
      b.Nome.toLowerCase().includes(s) 
      || b.Endereco.toLowerCase().includes(s) 
      || b.Cidade.toLowerCase().includes(s) 
      || b.UF.toLowerCase().includes(s)
    ));
  }
  
  function handleOrderClick(){
    let newList = JSON.parse(JSON.stringify(originalData));
      newList.sort((a, b) => (a.Nome > b.Nome)?1:(b.Nome > a.Nome)?-1:0);
      setBarbearias(newList)
  }

	return (

    <ImageBackground source={require('../assets/fundo.jpg')} resizeMode="cover" style={styles.container}>

      <View style={styles.containerHeader}>
        <Text style={styles.headerText}>corte no app</Text>
      </View>

      <View style={styles.inputContainer}>

        <TouchableWithoutFeedback>
          <Ionicons style={styles.icon} name="search-outline" size={20} color="white"/>
        </TouchableWithoutFeedback>

        <TextInput 
          placeholder={'Pesquise aqui...'} 
          placeholderTextColor="#DCDCDC" 
          onChangeText={(s) => search(s.toLowerCase())}
          style={styles.inputPesquisa}
        />

        <TouchableWithoutFeedback onPress={handleOrderClick}>
          <MaterialCommunityIcons style={styles.icon} name="sort-alphabetical-ascending" size={20} color="white"/>
        </TouchableWithoutFeedback>

      </View>

      {/*<Pesquisa/>*/}

      <FlatList
        showsVerticalScrollIndicator={false}
        showsHorizontalScrollIndicator={false}
        data={barbearias}
        keyExtractor={item => item.key}
        renderItem = { ({item}) =>(
          
          <View style={styles.container}>

            <View style={styles.card}>
    
              <View style={{alignItems:"center"}}>
                <Image style={styles.img} source={item.Imagem}/>
              </View>
    
              <View style={{paddingTop:5}}>
                <Text style={styles.nomebarbearia}>{item.Nome}</Text>
              </View>
    
              <Text style={{fontSize:10, paddingLeft: 16}}>
                {item.Telefone}
              </Text>
    
              <View style={{flexDirection:"row", justifyContent:"flex-start", paddingTop:10}}>
                <View style={{flexDirection:"column", flex: 1, paddingHorizontal: 16}}>
                  <Text style={styles.servicolocalizacao, {fontSize: '16', paddingBottom: 4}}>Serviços</Text>
                  <Text>
                    <FlatList
                      showsVerticalScrollIndicator={false}
                      showsHorizontalScrollIndicator={false}
                      data={item.Servicos}
                      keyExtractor={item => item.key}
                      renderItem = { ({item}) =>(
                        <Text style={styles.servicolocalizacao}>- {item}</Text>
                      )}
                    />
                  </Text>
                </View>
    
                <View style={{flexDirection:"column", flex: 1}}>
                  <Text style={styles.servicolocalizacao, {fontSize: '16', paddingBottom: 4}}>Localização</Text>
                  <Text style={styles.servicolocalizacao}>- {item.Endereco}</Text>
                  <Text style={styles.servicolocalizacao}>- {item.Cidade}</Text>
                  <Text style={styles.servicolocalizacao}>- {item.UF}</Text>
                </View>
              </View>
    
              <View style={{paddingTop: 30, marginLeft: 16, alignSelf: 'flex-start'}}>
                <TouchableOpacity style={styles.botao} onPress={() => {navigation.navigate('Servicos', {"id": item.id, "nome": item.Nome, "telefone": item.Telefone, "servicos": item.Servicos, "precos": item.Precos, "imagem": item.Imagem, 'email':email})}} >
                  <Text style={styles.botaoTexto}>AGENDAR</Text>
                </TouchableOpacity>
              </View>
            </View>
          </View>
        )
        }
      />
      
      <View style={styles.containerFab}>
        <TouchableWithoutFeedback onPress={alertaFab}>
          <View style={[styles.button, styles.menu]}>
            <Ionicons name='person' size={26} color ='black' />
          </View>
        </TouchableWithoutFeedback>
      </View>

      <StatusBar style='light'/>

    </ImageBackground>
	);
};

export default Home;

const styles = StyleSheet.create({
	container: {
		flexDirection: "column",
		flex:1,
		justifyContent:"center",
		alignItems:"center",
	},
  containerFab: {
    alignItems: 'center',
    position: 'absolute',
    marginRight: 40,
    marginBottom: 80,
    right: 0,
    bottom: 0,
  },
  containerHeader:{
    height: 90,
    width: '100%',
    backgroundColor: 'black',
    alignItems: 'center',
    justifyContent: 'center',
    paddingTop: 40,
  },
  inputContainer: {
    borderColor: '#FF5C00',
    borderWidth: 1,
    paddingLeft: 10,
    marginTop: 15,
    borderRadius: 45,
    flexDirection: 'row',
    marginVertical: 10,
    width: 300,
  },
  icon: {
    alignSelf: 'center',
  },
  inputPesquisa: {
    color: 'white', 
    fontSize: 14,
    fontVariant: ['small-caps'],
    fontWeight: 'normal',
    textAlign: 'center',
    padding: 10,
    width: 240,
  },
  headerText: {
    textAlign: 'center',
    fontSize: 24,
    color:"#FF5C00",
    fontVariant: ['small-caps'],
    fontWeight: 'normal',
  },
  button: {
    position: 'absolute',
    width: 60,
    height: 60,
    borderRadius: 60/2,
    justifyContent: 'center',
    alignItems: 'center',
    shadowRadius: 10,
    shadowColor: '#000',
    shadowOpacity: 0.3,
    shadowOffset: {
      height: 10,
    }
  },
  menu: {
    backgroundColor: '#FF5C00'
  },
	card:{
		backgroundColor: "#dcdcdc",
    borderRadius: 15,
    paddingBottom: 16,
		margin: 16,
		marginBottom: 20,
		elevation:15,
    width: 300,
	},
  nomebarbearia:{
    textAlign:"left", 
    fontSize:22, 
    color:"#FF5C00",
    fontVariant: ['small-caps'],
    fontWeight: 'normal',
    paddingHorizontal: 16,
  },
  servicolocalizacao:{
    textAlign:"left", 
    fontSize:12, 
    color:"black",
    fontVariant: ['small-caps'],
    fontWeight: 'normal',
  },
	img:{
		height: 104,
		width: 300,
		resizeMode:"cover",
		borderTopLeftRadius: 15,
    borderTopRightRadius: 15,
	},
	botao:{
		alignSelf: "center",
		justifyContent:"center",
		alignItems:"center",
		width: 120,
		height: 32,
		backgroundColor:"#FF5C00",
		borderRadius: 15,
		elevation: 10,
	},
	botaoTexto:{
		textAlign:"center",
		fontSize: 14,
		fontWeight:"bold",
	}
});