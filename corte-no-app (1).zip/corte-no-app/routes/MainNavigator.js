import React from 'react';
import {NavigationContainer} from '@react-navigation/native';
import {createNativeStackNavigator} from '@react-navigation/native-stack';

import Login from '../screens/Login';
import Cadastro from '../screens/Cadastro';
import EsqueciASenha from '../screens/EsqueciASenha';
import Home from '../screens/Home';
import Perfil from '../screens/Perfil';
import Servicos from '../screens/Servicos';
import Agendamento from '../screens/Agendamento';

export default function MainNavigator() {

  const Stack = createNativeStackNavigator();

  return <NavigationContainer>
        

          <Stack.Navigator 
            initialRouterName="Login"
            screenOptions={{
              headerStyle: {
                backgroundColor: '#000',
              },
              headerTintColor: '#FF5C00',
              headerTitleStyle: {
                fontSize: 20,
              },
            }}
          >
            <Stack.Screen 
              name="Login" 
              component={Login}
              options={{ headerShown: false }}
            />
            <Stack.Screen
              name="Cadastro"
              component={Cadastro}
            />
            <Stack.Screen
              name="EsqueciASenha"
              component={EsqueciASenha}
              options={{ 
                title: 'Recuperação de senha'
              }}
            />

            <Stack.Screen 
              name="Home" 
              component={Home}
              options={{ headerShown: false }}
            />
            <Stack.Screen
              name="Perfil"
              component={Perfil}
            />
            <Stack.Screen
              name="Servicos"
              component={Servicos}
              options={{
                title: 'Serviços & Preços',
              }}
            />
            <Stack.Screen
              name="Agendamento"
              component={Agendamento}
            />
          </Stack.Navigator>

  </NavigationContainer>
}